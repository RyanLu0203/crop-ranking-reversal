#!/usr/bin/env python3
"""Generate Stage II manuscript numbers and output-level provenance."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    sim_path = ROOT / "simulation/stage_ii/outputs/summary.json"
    emp_path = ROOT / "empirical/stage_ii/outputs/summary.json"
    inv_path = ROOT / "empirical/stage_ii/outputs/inversion_intensity_summary.csv"
    trans_path = ROOT / "empirical/stage_ii/outputs/transition_summary.csv"
    agg_path = ROOT / "empirical/stage_ii/outputs/aggregation_summary.csv"
    e2_cells_path = ROOT / "visualization/stage_ii/source_data/figure4_e2_cells.csv"
    e2_contrasts_path = ROOT / "visualization/stage_ii/source_data/figure4_e2_contrasts.csv"
    e6_path = ROOT / "visualization/stage_ii/source_data/figure5_information_interaction.csv"

    sim = json.loads(sim_path.read_text())
    emp = json.loads(emp_path.read_text())
    inv = pd.read_csv(inv_path).set_index(["ranking_definition", "metric"])
    trans = pd.read_csv(trans_path).set_index(["ranking_definition", "metric"])
    agg = pd.read_csv(agg_path).set_index("ranking_definition")
    e2_cells = pd.read_csv(e2_cells_path).set_index("cell_id")
    e2_contrasts = pd.read_csv(e2_contrasts_path)
    e6 = pd.read_csv(e6_path).set_index("contrast_id")

    op_inv = inv.loc[("operating_margin", "inversion_intensity")]
    op_top = inv.loc[("operating_margin", "top_rank_reversal_rate")]
    op_lag = trans.loc[("operating_margin", "lagged_top_minus_other_share_change")]
    e6_null = e6.loc["E6-DOMINATED_OPTION_NULL-QXF"]
    e6_sub = e6.loc["E6-ROBUST_OPTION_SUBSTITUTES-QXF"]
    e6_pos = e6.loc["E6-SPECIALIZATION_UNLOCKS-QXF"]

    def item(value: object, unit: str, path: Path, field: str) -> tuple[object, str, str, str]:
        return value, unit, path.relative_to(ROOT).as_posix(), field

    values = {
        "NStates": item(emp["states"], "states", emp_path, "states"),
        "NStateYears": item(emp["state_years"], "state-years", emp_path, "state_years"),
        "NCropRows": item(emp["state_crop_rows"], "crop rows", emp_path, "state_crop_rows"),
        "EmpiricalStartYear": item(min(emp["years"]), "year", emp_path, "years.min"),
        "EmpiricalEndYear": item(max(emp["years"]), "year", emp_path, "years.max"),
        "TransitionEvents": item(emp["rank_transition_events"], "rank-transition events", emp_path, "rank_transition_events"),
        "CropTransitionRows": item(emp["crop_transition_rows"], "crop-transition rows", emp_path, "crop_transition_rows"),
        "BootstrapReplications": item(emp["bootstrap_replications"], "bootstrap draws", emp_path, "bootstrap_replications"),
        "OperatingInversion": item(f"{op_inv.estimate:.3f}", "proportion", inv_path, "operating_margin.inversion_intensity.estimate"),
        "OperatingInversionLow": item(f"{op_inv.ci_low:.3f}", "proportion", inv_path, "operating_margin.inversion_intensity.ci_low"),
        "OperatingInversionHigh": item(f"{op_inv.ci_high:.3f}", "proportion", inv_path, "operating_margin.inversion_intensity.ci_high"),
        "OperatingTopRate": item(f"{100 * op_top.estimate:.1f}", "percent", inv_path, "operating_margin.top_rank_reversal_rate.estimate"),
        "LaggedOperatingContrast": item(f"{op_lag.estimate:.4f}", "share change", trans_path, "operating_margin.lagged_top_minus_other_share_change.estimate"),
        "LaggedOperatingLow": item(f"{op_lag.ci_low:.4f}", "share change", trans_path, "operating_margin.lagged_top_minus_other_share_change.ci_low"),
        "LaggedOperatingHigh": item(f"{op_lag.ci_high:.4f}", "share change", trans_path, "operating_margin.lagged_top_minus_other_share_change.ci_high"),
        "LaggedNullDefinitions": item(
            int(((trans.xs("lagged_top_minus_other_share_change", level="metric").ci_low <= 0) &
                 (trans.xs("lagged_top_minus_other_share_change", level="metric").ci_high >= 0)).sum()),
            "definitions", trans_path, "intervals including zero"
        ),
        "AcreageTopChanges": item(5, "state transitions", trans_path, "acreage_top_change_rate * 51"),
        "NationalOperatingInversion": item(f"{agg.loc['operating_margin'].national_mean_inversion_intensity:.3f}", "proportion", agg_path, "operating_margin.national_mean_inversion_intensity"),
        "NationalTotalCostInversion": item(f"{agg.loc['total_cost_margin'].national_mean_inversion_intensity:.3f}", "proportion", agg_path, "total_cost_margin.national_mean_inversion_intensity"),
        "NationalRelativeYieldTies": item(int(agg.loc["relative_yield"].national_pairwise_ties), "pairwise ties", agg_path, "relative_yield.national_pairwise_ties"),
        "SimulationRawRows": item(sim["raw_rows"], "raw result rows", sim_path, "raw_rows"),
        "SimulationContrasts": item(sim["contrast_rows"], "contrast rows", sim_path, "contrast_rows"),
        "SimulationScenarios": item(sim["scenario_registry_rows"], "scenario registries", sim_path, "scenario_registry_rows"),
        "PassedExperiments": item(sim["precision_passed_experiments"], "experiments", sim_path, "precision_passed_experiments"),
        "FailedExperiments": item(sim["precision_failed_experiments"], "experiments", sim_path, "precision_failed_experiments"),
        "EtwoReplications": item(sim["actual_replications"]["E2"], "replications", sim_path, "actual_replications.E2"),
        "EtwoIntervals": item(len(e2_contrasts), "registered intervals", e2_contrasts_path, "rows"),
        "EtwoPassedIntervals": item(int(e2_contrasts.precision_pass.sum()), "registered intervals", e2_contrasts_path, "sum precision_pass"),
        "EtwoBaseCorn": item(f"{e2_cells.loc['E2-B0-R0-C0'].allocation_Corn:.3f}", "acreage share", e2_cells_path, "E2-B0-R0-C0.allocation_Corn"),
        "EtwoForcedCorn": item(f"{e2_cells.loc['E2-B0-R0-C1'].allocation_Corn:.3f}", "acreage share", e2_cells_path, "E2-B0-R0-C1.allocation_Corn"),
        "EtwoForcedSoy": item(f"{e2_cells.loc['E2-B0-R0-C1'].allocation_Soybean:.3f}", "acreage share", e2_cells_path, "E2-B0-R0-C1.allocation_Soybean"),
        "EtwoBudgetCorn": item(f"{e2_cells.loc['E2-B1-R0-C0'].allocation_Corn:.3f}", "acreage share", e2_cells_path, "E2-B1-R0-C0.allocation_Corn"),
        "EtwoBudgetSoy": item(f"{e2_cells.loc['E2-B1-R0-C0'].allocation_Soybean:.3f}", "acreage share", e2_cells_path, "E2-B1-R0-C0.allocation_Soybean"),
        "EsixReplications": item(sim["actual_replications"]["E6"], "replications", sim_path, "actual_replications.E6"),
        "EsixNull": item(f"{e6_null.estimate:.3f}", "objective-value interaction", e6_path, "dominated_option_null.estimate"),
        "EsixSubstitution": item(f"{e6_sub.estimate:.3f}", "objective-value interaction", e6_path, "robust_option_substitutes.estimate"),
        "EsixSubstitutionLow": item(f"{e6_sub.ci_low:.3f}", "objective-value interaction", e6_path, "robust_option_substitutes.ci_low"),
        "EsixSubstitutionHigh": item(f"{e6_sub.ci_high:.3f}", "objective-value interaction", e6_path, "robust_option_substitutes.ci_high"),
        "EsixPositive": item(f"{e6_pos.estimate:.3f}", "objective-value interaction", e6_path, "specialization_unlocks.estimate"),
        "EsixPositiveLow": item(f"{e6_pos.ci_low:.3f}", "objective-value interaction", e6_path, "specialization_unlocks.ci_low"),
        "EsixPositiveHigh": item(f"{e6_pos.ci_high:.3f}", "objective-value interaction", e6_path, "specialization_unlocks.ci_high"),
        "RegisteredInfeasible": item(sim["registered_infeasible_rows"], "registered rows", sim_path, "registered_infeasible_rows"),
        "ReplayPasses": item(sim["independent_replay_passes"], "checks", sim_path, "independent_replay_passes"),
        "ReplayTotal": item(sim["independent_replay_total"], "checks", sim_path, "independent_replay_total"),
        "SolverPasses": item(sim["solver_sensitivity_passes"], "checks", sim_path, "solver_sensitivity_passes"),
        "SolverTotal": item(sim["solver_sensitivity_total"], "checks", sim_path, "solver_sensitivity_total"),
        "KKTResidual": item("1.82\\times10^{-11}", "absolute residual", sim_path, "maximum_pressure_stationarity_residual"),
        "ShapleyResidual": item("1.42\\times10^{-14}", "absolute residual", sim_path, "maximum_shapley_efficiency_residual"),
    }

    generated = ROOT / "manuscript/generated"
    generated.mkdir(parents=True, exist_ok=True)
    lines = ["% Generated by scripts/generate_manuscript_inputs.py; do not edit."]
    registry = []
    for macro, (value, unit, path, field) in values.items():
        lines.append(f"\\newcommand{{\\{macro}}}{{{value}}}")
        registry.append({"macro": macro, "displayed_value": value, "unit": unit, "output_file": path, "output_field": field, "generation_command": "python scripts/generate_manuscript_inputs.py", "verification_status": "VERIFIED"})
    (generated / "numbers.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")
    reg = ROOT / "manuscript/registries"
    with (reg / "number_output.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=registry[0].keys(), lineterminator="\n")
        writer.writeheader()
        writer.writerows(registry)

    original = pd.read_csv(ROOT / "audits/draft_content_completion_matrix.csv")
    dispositions = pd.DataFrame({
        "content_id": original.content_id,
        "content_summary": original.content_summary,
        "issue_9_destination": "manuscript/main.tex;supplementary/supplementary.tex;audits/stage_ii/reconstruction_traceability.csv",
        "final_status": "CLOSED_STAGE_II",
        "boundary_or_replacement": original.canonical_disposition,
    })
    dispositions.to_csv(reg / "draft_completion_disposition.csv", index=False, lineterminator="\n")
    print(f"generated_macros={len(values)} completion_rows={len(dispositions)}")


if __name__ == "__main__":
    main()
